from abc import ABC,abstractmethod
class Scanner(ABC):
    name="base"; supported_types=set()
    def supports(self,i): return i.type in self.supported_types
    @abstractmethod
    def scan(self,identifier,investigation_id,actor_id): ...
