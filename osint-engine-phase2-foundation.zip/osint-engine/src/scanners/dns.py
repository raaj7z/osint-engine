import socket
from .base import Scanner
from ..models import Finding
class DNSScanner(Scanner):
    name="dns"; supported_types={"domain","url"}
    def scan(self,i,investigation_id,actor_id):
        host=i.value.split("://",1)[-1].split("/",1)[0]; out=[]
        try: ips=sorted({x[4][0] for x in socket.getaddrinfo(host,None)})
        except (socket.gaierror,OSError): ips=[]
        for ip in ips: out.append(Finding(investigation_id=investigation_id,actor_id=actor_id,finding_type="ip",value=ip,source=self.name,confidence=.6,metadata={"resolved_from":host}))
        return out
