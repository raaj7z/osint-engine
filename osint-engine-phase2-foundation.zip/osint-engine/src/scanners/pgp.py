from .base import Scanner
from ..models import Finding
class PgpScanner(Scanner):
    name="pgp"; supported_types={"pgp"}
    def scan(self,identifier,investigation_id,actor_id):
        return [Finding(investigation_id=investigation_id,actor_id=actor_id,finding_type="pgp",value=identifier.value,source=self.name,confidence=identifier.confidence,metadata={"status":"seed_identifier"})]
PgpScanner=PGPScanner
