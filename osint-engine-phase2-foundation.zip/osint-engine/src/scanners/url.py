from .base import Scanner
from ..models import Finding
class URLScanner(Scanner):
    name="url"; supported_types={"url"}
    def scan(self,identifier,investigation_id,actor_id):
        return [Finding(investigation_id=investigation_id,actor_id=actor_id,finding_type="url",value=identifier.value,source=self.name,confidence=identifier.confidence,metadata={"status":"seed_identifier"})]
