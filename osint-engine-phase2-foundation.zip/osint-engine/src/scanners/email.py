from .base import Scanner
from ..models import Finding
class EmailScanner(Scanner):
    name="email"; supported_types={"email"}
    def scan(self,identifier,investigation_id,actor_id):
        return [Finding(investigation_id=investigation_id,actor_id=actor_id,finding_type="email",value=identifier.value,source=self.name,confidence=identifier.confidence,metadata={"status":"seed_identifier"})]
