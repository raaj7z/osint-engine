from .base import Scanner
from ..models import Finding
class IpScanner(Scanner):
    name="ip"; supported_types={"ip"}
    def scan(self,identifier,investigation_id,actor_id):
        return [Finding(investigation_id=investigation_id,actor_id=actor_id,finding_type="ip",value=identifier.value,source=self.name,confidence=identifier.confidence,metadata={"status":"seed_identifier"})]
IpScanner=IPScanner
