from .base import Scanner
from ..models import Finding
class UsernameScanner(Scanner):
    name="username"; supported_types={"username"}
    def scan(self,identifier,investigation_id,actor_id):
        return [Finding(investigation_id=investigation_id,actor_id=actor_id,finding_type="username",value=identifier.value,source=self.name,confidence=identifier.confidence,metadata={"status":"seed_identifier"})]
