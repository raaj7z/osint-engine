import os
from .base import Provider
class ShodanProvider(Provider):
    name="shodan"; supported_types={"ip","domain"}
    def query(self,identifier,investigation_id,actor_id):
        # Add authenticated, rate-aware public API calls here; never bypass provider controls.
        if not self._configured(): return []
        return []
    def _configured(self): return bool(os.getenv("SHODAN_API_KEY"))
ShodanProvider=ShodanProvider
