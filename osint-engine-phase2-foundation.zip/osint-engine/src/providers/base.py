from abc import ABC,abstractmethod
class Provider(ABC):
    name="base"; supported_types=set()
    def supports(self,i): return i.type in self.supported_types
    @abstractmethod
    def query(self,identifier,investigation_id,actor_id): ...
