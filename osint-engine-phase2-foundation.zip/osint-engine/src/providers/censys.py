import os
from .base import Provider
class CensysProvider(Provider):
    name="censys"; supported_types={"ip","domain"}
    def query(self,identifier,investigation_id,actor_id):
        return [] if not (os.getenv("CENSYS_API_ID") and os.getenv("CENSYS_API_SECRET")) else []
