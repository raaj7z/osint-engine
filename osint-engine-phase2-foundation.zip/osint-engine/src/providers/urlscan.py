import os
from .base import Provider
class UrlscanProvider(Provider):
    name="urlscan"; supported_types={"url","domain"}
    def query(self,identifier,investigation_id,actor_id):
        # Add authenticated, rate-aware public API calls here; never bypass provider controls.
        if not self._configured(): return []
        return []
    def _configured(self): return bool(os.getenv("URLSCAN_API_KEY"))
UrlscanProvider=URLScanProvider
