import json
from pathlib import Path
def to_json(result,path=None):
    s=json.dumps(result.model_dump(mode="json"),indent=2,ensure_ascii=False)
    if path: Path(path).write_text(s,encoding="utf-8")
    return s
