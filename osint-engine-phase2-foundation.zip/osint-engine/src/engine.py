import argparse
from datetime import datetime,timezone
from .input import make_investigation
from .normalizer import normalize_identifier
from .models import InvestigationInput,InvestigationResult,Finding
from .scanners.username import UsernameScanner
from .scanners.email import EmailScanner
from .scanners.url import URLScanner
from .scanners.domain import DomainScanner
from .scanners.dns import DNSScanner
from .scanners.ip import IpScanner
from .scanners.pgp import PgpScanner
from .scanners.crypto import CryptoScanner
from .providers.virustotal import VirustotalProvider
from .providers.shodan import ShodanProvider
from .providers.censys import CensysProvider
from .providers.urlscan import UrlscanProvider
class OSINTEngine:
    def __init__(self):
        self.scanners=[UsernameScanner(),EmailScanner(),URLScanner(),DomainScanner(),DNSScanner(),IpScanner(),PgpScanner(),CryptoScanner()]
        self.providers=[VirustotalProvider(),ShodanProvider(),CensysProvider(),UrlscanProvider()]
    def run(self,investigation:InvestigationInput):
        r=InvestigationResult(investigation_id=investigation.investigation_id,actor_id=investigation.actor_id,started_at=datetime.now(timezone.utc))
        for i in map(normalize_identifier,investigation.identifiers):
            for s in self.scanners:
                if s.supports(i):
                    try:r.findings.extend(s.scan(i,investigation.investigation_id,investigation.actor_id))
                    except Exception as e:r.errors.append(f"{s.name}: {type(e).__name__}: {e}")
            for p in self.providers:
                if p.supports(i):
                    try:r.findings.extend(p.query(i,investigation.investigation_id,investigation.actor_id))
                    except Exception as e:r.errors.append(f"{p.name}: {type(e).__name__}: {e}")
        seen=set(); r.findings=[f for f in r.findings if not ((k:=(f.finding_type,f.value.lower(),f.source,f.source_url)) in seen or seen.add(k))]
        r.completed_at=datetime.now(timezone.utc); return r
def main():
    p=argparse.ArgumentParser();
    for x in ["username","email","url","domain","ip","pgp","wallet"]: p.add_argument("--"+x)
    a=p.parse_args(); print(OSINTEngine().run(make_investigation(**vars(a))).model_dump_json(indent=2))
if __name__=="__main__": main()
