import re
EMAIL_RE=re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b",re.I)
URL_RE=re.compile(r"https?://[^\s<>\"]+")
def extract_basic_entities(text): return {"emails":sorted(set(EMAIL_RE.findall(text))),"urls":sorted(set(URL_RE.findall(text)))}
