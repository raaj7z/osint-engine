import hashlib
from ..models import Evidence
def evidence_from_text(source,source_url,text,title=None): return Evidence(source=source,source_url=source_url,title=title,excerpt=text[:2000],hash_sha256=hashlib.sha256(text.encode()).hexdigest())
