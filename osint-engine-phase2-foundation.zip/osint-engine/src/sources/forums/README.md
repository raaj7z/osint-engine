# Forum adapters

Add one adapter per public/authorized forum or source. Each adapter should return normalized findings and preserve source URL, timestamp, evidence excerpt, and collection metadata. Do not implement authentication bypass or rate-limit evasion.
