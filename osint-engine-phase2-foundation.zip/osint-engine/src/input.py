import uuid
from typing import Any
from .models import Identifier, InvestigationInput

def make_investigation(**kwargs):
    iid=kwargs.pop("investigation_id",None) or str(uuid.uuid4()); actor=kwargs.pop("actor_id",None)
    mapping={"username":"username","email":"email","url":"url","domain":"domain","ip":"ip","pgp":"pgp","wallet":"crypto"}
    ids=[Identifier(type=k,value=str(v)) for k,v in kwargs.items() if v and k in mapping]
    return InvestigationInput(investigation_id=iid,actor_id=actor,identifiers=ids)

def from_crawler_actor_report(report: dict[str,Any]):
    ids=[]
    for x in report.get("identifiers",[]):
        if isinstance(x,dict) and x.get("type") and x.get("value"): ids.append(Identifier(**x))
    mapping={"username":"username","handle":"username","email":"email","url":"url","domain":"domain","ip":"ip","pgp":"pgp","wallet":"crypto","wallet_address":"crypto"}
    for key,kind in mapping.items():
        if report.get(key): ids.append(Identifier(type=kind,value=str(report[key]),source="crawler"))
    return InvestigationInput(investigation_id=str(report.get("investigation_id") or report.get("session_id") or uuid.uuid4()),actor_id=report.get("actor_id"),identifiers=ids,notes=report.get("notes"))
