from urllib.parse import urlsplit,urlunsplit
from .models import Identifier
def normalize_value(kind,value):
    value=value.strip()
    if kind=="username": return value.lstrip("@").lower()
    if kind=="email": return value.lower()
    if kind=="domain": return value.lower().rstrip(".")
    if kind=="url":
        p=urlsplit(value); return urlunsplit((p.scheme.lower(),(p.hostname or "").lower(),p.path or "/",p.query,""))
    if kind=="pgp": return "".join(value.split()).upper()
    return value
def normalize_identifier(i): return i.model_copy(update={"value":normalize_value(i.type,i.value)})
