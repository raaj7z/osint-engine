from dataclasses import dataclass,field
from datetime import datetime,timezone
@dataclass
class WatchlistEntry:
    actor_id:str; identifiers:list[str]=field(default_factory=list); sources:list[str]=field(default_factory=list); interval_hours:int=24; status:str="ACTIVE"; created_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
class WatchlistStore:
    def __init__(self): self._entries={}
    def add(self,e): self._entries[e.actor_id]=e
    def get(self,actor_id): return self._entries.get(actor_id)
    def all(self): return list(self._entries.values())
