from datetime import datetime,timezone
def due(entry,now=None): return entry.status=="ACTIVE" and (now or datetime.now(timezone.utc))>=entry.created_at
