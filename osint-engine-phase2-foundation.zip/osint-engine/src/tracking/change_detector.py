def detect_changes(previous,current):
    p={(f.finding_type,f.value,f.source) for f in previous}; c={(f.finding_type,f.value,f.source) for f in current}
    return {"added":[f for f in current if (f.finding_type,f.value,f.source) in c-p],"removed":[f for f in previous if (f.finding_type,f.value,f.source) in p-c]}
