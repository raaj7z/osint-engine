from src.models import Identifier
from src.normalizer import normalize_identifier
def test_normalize(): assert normalize_identifier(Identifier(type="username",value="@Example_User")).value=="example_user"
