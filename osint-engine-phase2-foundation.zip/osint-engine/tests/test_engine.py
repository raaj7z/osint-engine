from src.engine import OSINTEngine
from src.input import make_investigation
def test_engine():
    r=OSINTEngine().run(make_investigation(username="@Example",domain="example.com",ip="192.0.2.1"))
    assert len(r.findings)>=3
    assert r.errors==[]
